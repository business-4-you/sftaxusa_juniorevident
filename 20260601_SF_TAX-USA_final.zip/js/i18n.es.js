/* SF TAX USA — Español (es) */
window.I18N = window.I18N || {};
window.I18N.es = {
  meta: {
    homeTitle: "SF TAX USA | Contabilidad e Impuestos en Florida para Empresas y Extranjeros",
    homeDesc: "Contabilidad, preparación de impuestos y orientación fiscal en Florida para brasileños, extranjeros y empresas. Hable con un especialista de SF TAX USA — atención en español, portugués e inglés."
  },
  nav: {
    home: "Inicio", about: "Nosotros", services: "Servicios",
    insights: "Insights", contact: "Contacto", allServices: "Ver todos los servicios",
    menuTitle: "Menú"
  },
  cta: {
    specialist: "Hable con un especialista",
    whatsapp: "WhatsApp",
    seeServices: "Ver servicios",
    requestAnalysis: "Solicitar un análisis",
    schedule: "Agendar una consulta",
    learnMore: "Saber más",
    sendMessage: "Enviar mensaje",
    talkNow: "Hablar ahora"
  },
  hero: {
    eyebrow: "Contabilidad • Impuestos • Negocios en EE. UU.",
    titleA: "Contabilidad e impuestos para quienes ",
    titleAccent: "viven, emprenden o invierten",
    titleB: " en los Estados Unidos.",
    sub: "SF TAX USA ayuda a brasileños, latinos, extranjeros y empresas en Florida a mantener su vida fiscal organizada, segura y lista para crecer — con orientación profesional en español, portugués e inglés.",
    trust1: "Atención en 3 idiomas",
    trust2: "Especialistas en residentes y extranjeros",
    trust3: "Enfoque en plazos y cumplimiento (IRS)",
    floatAName: "Respuesta el mismo día",
    floatALabel: "Atención humana y cercana",
    floatBName: "Siempre en regla",
    floatBLabel: "Plazos del IRS y de Florida",
    imgLabel: "[ foto: equipo / oficina SF TAX USA — Florida ]"
  },
  strip: {
    a: "Personas y familias",
    b: "Empresas y LLC",
    c: "Brasileños y extranjeros en EE. UU.",
    d: "Inversionistas y autónomos"
  },
  pains: {
    eyebrow: "¿Se identifica?",
    title: "Lidiar con los impuestos en EE. UU. no tiene por qué ser estresante",
    sub: "La mayoría de nuestros clientes llega con una de estas preocupaciones. Si alguna es la suya, podemos ayudar.",
    items: [
      "¿Está abriendo una empresa en EE. UU. y no sabe por dónde empezar?",
      "¿Necesita declarar impuestos y teme cometer errores?",
      "¿Tiene dudas sobre el Sales Tax y lo que debe recaudar?",
      "¿Recibe ingresos en Brasil y en EE. UU. al mismo tiempo?",
      "¿Necesita organizar la contabilidad de su empresa?",
      "¿Teme perder plazos y obligaciones fiscales?"
    ]
  },
  servicesHome: {
    eyebrow: "Nuestros servicios",
    title: "Soluciones contables y fiscales completas para su realidad en EE. UU.",
    sub: "Desde la apertura de su empresa hasta la declaración anual, cuidamos cada etapa con claridad y acompañamiento cercano.",
    cta: "Ver todos los servicios"
  },
  about: {
    eyebrow: "Sobre SF TAX USA",
    title: "Un socio contable que entiende la vida y la inversión entre dos países",
    p1: "SF TAX USA — Santiago & Felix Accounting Services nació para ser el puente entre brasileños, latinos y extranjeros y el sistema fiscal estadounidense. Sabemos que términos como IRS, Sales Tax, FBAR y FIRPTA pueden intimidar — por eso traducimos la complejidad en orientación clara y decisiones seguras.",
    p2: "Atendemos a personas, autónomos, empresarios e inversionistas que necesitan una contabilidad confiable en Florida, con comunicación cercana en español, portugués e inglés y total atención a los plazos y al cumplimiento.",
    stat1n: "3", stat1l: "Idiomas de atención",
    stat2n: "14+", stat2l: "Servicios especializados",
    stat3n: "100%", stat3l: "Enfoque en cumplimiento",
    cta: "Conozca nuestro enfoque"
  },
  why: {
    eyebrow: "Por qué elegir SF TAX USA",
    title: "Confianza, claridad y acompañamiento en cada etapa",
    items: [
      { i:"chat",  t:"Atención en su idioma", d:"Español, portugués e inglés. Lo atiende quien entiende su contexto y habla su idioma." },
      { i:"shield",t:"Cumplimiento primero", d:"Trabajamos con responsabilidad y atención a los plazos del IRS y del estado de Florida, reduciendo riesgos." },
      { i:"globe2",t:"Visión de dos países", d:"Experiencia con quienes tienen vida, ingresos o patrimonio en Brasil y en EE. UU." },
      { i:"clock", t:"Cercanía y agilidad", d:"Comunicación directa y respuestas rápidas — para que no se pierda en la burocracia." },
      { i:"target",t:"Orientación para decidir", d:"Más que ejecutar, le ayudamos a entender el porqué y a tomar mejores decisiones." },
      { i:"users", t:"Personas y empresas", d:"Soluciones para individuos, autónomos, familias, LLC y empresas en crecimiento." }
    ]
  },
  process: {
    eyebrow: "Cómo funciona",
    title: "Un camino simple y organizado, del primer contacto al acompañamiento",
    steps: [
      { t:"Conversación inicial", d:"Entendemos su situación, sus objetivos y lo que hay que resolver." },
      { t:"Diagnóstico", d:"Analizamos documentos y mapeamos obligaciones, plazos y oportunidades." },
      { t:"Organización", d:"Estructuramos su documentación y definimos el mejor camino." },
      { t:"Ejecución", d:"Realizamos el servicio con precisión y transparencia en cada etapa." },
      { t:"Acompañamiento", d:"Seguimos a su lado para mantener todo en regla durante el año." }
    ]
  },
  langband: {
    eyebrow: "Atención multilingüe",
    title: "Hablamos su idioma — literalmente",
    sub: "No necesita traducir su vida fiscal. Explicamos cada paso con claridad en el idioma en el que se siente más cómodo.",
    pills: [
      { flag:"🇧🇷", t:"Português", d:"Para brasileños en EE. UU." },
      { flag:"🇺🇸", t:"English", d:"Para residentes y extranjeros" },
      { flag:"🇪🇸", t:"Español", d:"Para la comunidad latina" }
    ]
  },
  blog: {
    eyebrow: "Insights",
    title: "Contenidos para decidir con más seguridad",
    sub: "Explicaciones prácticas sobre impuestos, empresas y obligaciones fiscales en los Estados Unidos.",
    cta: "Ver todos los contenidos",
    posts: [
      { cat:"Impuestos", t:"Cómo declarar impuestos en EE. UU. siendo extranjero", e:"Entienda quién debe declarar, los plazos y los cuidados clave para no equivocarse." },
      { cat:"Empresas", t:"Cómo abrir una empresa en Florida paso a paso", e:"LLC, EIN, cuenta bancaria y obligaciones iniciales explicados de forma simple." },
      { cat:"Sales Tax", t:"Qué es el Sales Tax y cuándo su empresa debe recaudarlo", e:"Sepa cuándo el impuesto sobre ventas aplica a su negocio en Florida." },
      { cat:"Contabilidad", t:"Por qué mantener la contabilidad mensual al día en EE. UU.", e:"Cómo la organización continua evita dolores de cabeza y mejora decisiones." },
      { cat:"Planificación", t:"Planificación fiscal vs. preparación de impuestos", e:"No son lo mismo — entienda la diferencia y por qué ambas importan." },
      { cat:"Internacional", t:"Obligaciones fiscales si tiene ingresos o bienes fuera de EE. UU.", e:"FBAR, FATCA y lo que los residentes deben reportar al IRS." }
    ]
  },
  contact: {
    eyebrow: "Hable con nosotros",
    title: "Organicemos su vida fiscal en EE. UU.",
    sub: "Cuéntenos qué necesita. Respondemos con orientación clara y el siguiente paso — sin compromiso.",
    waTitle: "WhatsApp", waText: "Respuesta rápida en horario comercial",
    phoneTitle: "Teléfono", emailTitle: "Correo",
    addrTitle: "Oficina", addrText: "Florida, Estados Unidos",
    hoursTitle: "Horario", hoursText: "Lun–Vie, 9:00 a 18:00 (EST)",
    formTitle: "Solicite un análisis",
    f_name: "Nombre completo", f_email: "Correo", f_phone: "Teléfono / WhatsApp",
    f_lang: "Idioma preferido", f_service: "Tipo de servicio", f_msg: "¿Cómo podemos ayudar?",
    f_servicePlaceholder: "Seleccione un servicio",
    f_msgPlaceholder: "Describa brevemente su situación...",
    submit: "Solicitar análisis",
    privacy: "Al enviar, acepta nuestra Política de Privacidad. No compartimos sus datos.",
    success: "¡Recibimos su mensaje! Nos pondremos en contacto pronto."
  },
  faq: {
    eyebrow: "Preguntas frecuentes",
    title: "Dudas comunes de quienes empiezan con nosotros",
    items: [
      { q:"¿Atienden a clientes fuera de Florida?", a:"Sí. Atendemos a clientes en distintos estados y también a personas que viven fuera de EE. UU. con obligaciones fiscales estadounidenses, de forma remota y segura." },
      { q:"¿Necesito tener empresa para que me atiendan?", a:"No. Atendemos a personas, autónomos, familias, inversionistas y empresas. El servicio se adapta a su situación." },
      { q:"¿En qué idiomas atienden?", a:"Atendemos en español, portugués e inglés, para que entienda cada paso con claridad." },
      { q:"¿Cómo funciona el primer contacto?", a:"Nos escribe por WhatsApp o el formulario, entendemos su necesidad e indicamos el mejor camino, sin compromiso." },
      { q:"¿Ayudan a quienes tienen ingresos en Brasil y en EE. UU.?", a:"Sí. Es una de nuestras especialidades: orientar a quienes tienen ingresos, cuentas o patrimonio en ambos países para cumplir correctamente." }
    ]
  },
  ctaband: {
    title: "Evite errores fiscales. Hable con quienes saben del tema.",
    sub: "Dé el primer paso para organizar su contabilidad y sus impuestos en los Estados Unidos con seguridad.",
    primary: "Hablar por WhatsApp",
    secondary: "Solicitar un análisis"
  },
  footer: {
    tagline: "Santiago & Felix Accounting Services. Contabilidad, impuestos y orientación fiscal en Florida para brasileños, extranjeros y empresas.",
    colServices: "Servicios", colCompany: "Empresa", colLegal: "Legal",
    aboutLink: "Nosotros", insightsLink: "Insights", contactLink: "Contacto", faqLink: "Preguntas frecuentes",
    privacy: "Política de Privacidad", terms: "Términos de Uso",
    rights: "Todos los derechos reservados.",
    disclaimer: "La información de este sitio tiene carácter informativo y no constituye asesoría contable, fiscal o legal específica. Cada situación debe evaluarse individualmente. SF TAX USA no garantiza resultados fiscales ni ahorro de impuestos; nuestro compromiso es la orientación profesional y responsable conforme a la legislación aplicable.",
    madeWith: "Atención en español, portugués e inglés."
  },
  svc: {
    breadcrumbHome: "Inicio", breadcrumbServices: "Servicios",
    painTitle: "El desafío",
    solutionTitle: "Cómo ayuda SF TAX USA",
    forWhoTitle: "Para quién es este servicio",
    benefitsTitle: "Lo que usted gana",
    howTitle: "Cómo funciona",
    faqTitle: "Preguntas frecuentes",
    relatedTitle: "Otros servicios que pueden interesarle",
    heroCtaPrimary: "Hable con un especialista",
    heroCtaSecondary: "Solicitar un análisis",
    finalTitle: "¿Listo para resolverlo con seguridad?",
    finalSub: "Hable con un especialista de SF TAX USA y entienda el mejor camino para su situación fiscal en EE. UU.",
    sidebarTitle: "Hable con un especialista",
    sidebarSub: "Atención en español, portugués e inglés. Respuesta rápida y sin compromiso.",
    sidebarCta: "Hablar por WhatsApp",
    sidebarForm: "Solicitar un análisis"
  },
  audience: {
    pf: "Personas físicas", empresas: "Empresas y LLC", brasileiros: "Brasileños en EE. UU.",
    estrangeiros: "Extranjeros que invierten en EE. UU.", autonomos: "Autónomos",
    empresarios: "Empresarios", investidores: "Inversionistas", imigrantes: "Inmigrantes",
    familias: "Familias", ecommerce: "Tiendas y e-commerce"
  },
  servicesPage: {
    title: "Servicios",
    eyebrow: "Qué hacemos",
    h1: "Servicios de contabilidad e impuestos en Florida",
    sub: "Soluciones completas para personas, empresas, brasileños y extranjeros en los Estados Unidos. Elija un servicio y hable con un especialista.",
    metaTitle: "Servicios de Contabilidad e Impuestos en Florida | SF TAX USA",
    metaDesc: "Conozca los servicios de SF TAX USA: preparación de impuestos, apertura de empresa, Sales Tax, planificación fiscal, FBAR, FIRPTA y más. Atención en 3 idiomas."
  }
};
